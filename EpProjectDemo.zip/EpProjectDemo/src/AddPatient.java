
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.sql.Date;

@WebServlet(name = "AddPatient", urlPatterns = {"/addpatient"})
@MultipartConfig
public class AddPatient extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            
        	String firstname=request.getParameter("patientfirstname");  
        	String lastname=request.getParameter("patientlastname");
        	String address=request.getParameter("patientaddress");
        	String email=request.getParameter("patientemail");
        	String phonenumber=request.getParameter("patientphonenumber");
        	String adate=request.getParameter("appointmentdate");
        	Date date=Date.valueOf(adate); 
        	String pid=request.getParameter("patientid");
        	int patientid = Integer.parseInt(pid);
        	String page=request.getParameter("patientage");
        	int age=Integer.parseInt(page);
        	String consulted_doctor=request.getParameter("patientconsulteddoctor");
        	String disease=request.getParameter("patientdisease");
        	String test=request.getParameter("patienttest");
        	String gender=request.getParameter("patientgender");
        	String pweight=request.getParameter("patientweight");
        	int weight=Integer.parseInt(pweight);
        	String blood_group=request.getParameter("patientbloodgroup");
            
            Part photo =  request.getPart("photo");
            Part reports = request.getPart("reports");        
           
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
            PreparedStatement ps= con.prepareStatement("insert into patient values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, firstname);
            ps.setString(2, lastname);
            ps.setString(3, phonenumber);
            ps.setString(4, email);
            ps.setString(5, address);
            ps.setDate(6, date);
            ps.setInt(7, patientid);
            ps.setInt(8, age);
            ps.setString(9, consulted_doctor);
            ps.setString(10, disease);
            ps.setString(11, test);
            ps.setString(12, gender);
            ps.setInt(13, weight);
            ps.setString(14, blood_group);
            

            ps.setBinaryStream(15, photo.getInputStream(), (int)  photo.getSize());
            ps.setBinaryStream(16, reports.getInputStream(), (int)  reports.getSize());
            
           int x= ps.executeUpdate();
            con.commit();
            con.close();
            
            if(x>0) {
            	response.sendRedirect("index.html");
            }
        } 
        catch(Exception ex) {
            System.out.println(ex.getMessage());
        }
        finally {            
            out.close();
        }
	}

}
