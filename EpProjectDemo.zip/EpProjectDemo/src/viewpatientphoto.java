

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;


public class viewpatientphoto extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		byte[] img=null;
		ServletOutputStream sos=null;
		try {
			String name=request.getParameter("name");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "manager");
			PreparedStatement ps=con.prepareStatement("select * from patient where last_name=?");
			ps.setString(1, name);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				img=rs.getBytes(15);
			}
			sos=response.getOutputStream();
			sos.write(img);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
